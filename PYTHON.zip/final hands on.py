import os
def display_help():
    print('''
    =======> Help <=======
    'HELP' to display this menu
    'START' to start creating your shopping list
    'SHOW' to display your current items
    'QUIT' to exit the program
    ''')
def clear_screen():
    os.system("cls" if os.name == "nt" else "clear")
def payment_mode(amount):
    clear_screen()
    print("MODE OF PAYMENT")
    print("1.Cash on delivery\n2.Paytm\n3.credit card\n4.debit card")
    a=int(input("Enter mode of payment"))
    if a == 1 :
        print("cash on delivery is applied\nYour bill amount=",amount,"~~~~~~~~~~~~~~~\nThank you for shopping~~~~~~~~~~~~~\n\n")
        exit_con()
    elif a==2:
        print("^^Scan the QR code^^\n\nYour bill amount=",amount,"~~~~~~~~~~~~~~~\nThank you for shopping~~~~~~~~~~~~~\n\n")
        exit_con()
    elif a==3:
        b=input("Enter card number")
        c=input("Enter CVV")
        if len(b)==16 & len(c)==3:
            print("VALID\nYour bill amount=",amount,"~~~~~~~~~~~~~~~\nThank you for shopping~~~~~~~~~~~~~\n\n")
            exit_con()
        else:
           print("In valid")
           exit_con()

            
def shopping_list():
    clear_screen()
    print('It\'s time to go shopping!')
    clear_screen()
    item_dict = {}
    print('Enter HELP at any moment if you need help or EXIT to return to the main menu')
    cart = 0
    def show_items():
        for key, value in item_dict.items():
            print(key + '-' * 5 + str(value))
        print('Current cart total: ',sum(item_dict.values()))
    while True:
        print("1.chicken briyani-150\n2.mutton briyani-180\n3.chicken manjurian-100\n4.chicken noodles-200\n5.sechzewan rice-180\n6.fish fry-250\n7.grilled chicken-240\n8.butter chicken-150")
        shop = input('Please enter an item: ')
        if shop.upper() == 'HELP':
            display_help()
            conti
        elif shop.upper() == 'EXIT':
           
           print("Goodbye")
           break
        elif shop.upper() == 'SHOW':
            show_items()
            continue
        print(f'You have added {shop} to your list\n')
        
        
        qty = float(input(f'quantity of {shop}: '))
        cost=qty*200
        item_dict[shop] = cost
        cart = sum(item_dict.values())
        print(f'You entered {cost} as the price of {shop}\n')
        print(f'You now have {len(item_dict)} items in your list.\n')
        print(f'The total currently on your cart is {cart}')
        add_more_items = input('Would you like to add more items?(Y/N) ')
        if add_more_items == 'Y'.lower():
             continue
        else:
            s=sum(item_dict.values())
            print("\n\n")
            for key, value in item_dict.items():
                print('      ',key + '-' * 5 + str(value))
            print('\n      ******Current cart total: ',sum(item_dict.values()),'******')
            if s>500:
                print("\n\n*****OFFER APPLIED*******")
                s=s-100
                print('*****',s,'****\n\n')
                payment_mode(s)
            else:
                print("*******NO OFFER********\n\n")
                payment_mode(s)
def user():
    
    t1=0
    
    us1=[input("Enter the user_name:")]
    us2=[input("Enter the user_address:")]
    t1=us1[-1]
    
    u1=open("product1.txt","a")
    u1.write(str(us1))
    u1.write(str(us2))
    u1.write("\n")
    u1.close()
    
    u1=open("product1.txt","r")
    print(u1.read())
def exit_con():
    while True:
        print("Good bye")
        begin.attempt()


def begin_attempt():
    print('*********Welcome! What would you like to do?************')
    print('Our lists are\n1.Details\n2.shop\n3.help\n4.exit')

    while True:
        choose = input('> ')
        
        if choose.upper() == 'SHOP':
            print('*******Shopping has begun***********')
            shopping_list()
        elif choose.upper() == 'DETAILS':
            user()
            
        elif choose.upper() == 'HELP':
            display_help()
            continue
        elif choose.upper() == 'EXIT':
            print("Goodbye")
            break

begin_attempt()

