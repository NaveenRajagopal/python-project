import cx_Oracle
con = cx_Oracle.connect("ANAND/12")
cur = con.cursor()
class Userdetails:
    def getdata(self):
        u_id = input("Enter the ID:")
        u_name = input("Enter the username:")
        u_gender=input("Enter the gender:")
        u_collegename = input("Enter the college name")
        u_contactno=input("Enter the contact number:")
        u_emailid=input("Enter the mail ID:")
        u_password = input("Enter the password:")
        c_password = input("Confirm the password:")
        cur.execute ("select * from userdetails")
        print("\n\t\t\tYour registration is suuccessfull!!\n\n For more details contact Volunteers: \n\tMr.Naveen 9052462358\n\t Ms.Menaka 9823651298")
        cur.execute("insert into ANAND.userdetails values('%s','%s','%s','%s','%s','%s','%s','%s')"%(u_id,u_name,u_gender,u_collegename,u_contactno,
                                                                                                         u_emailid,u_password,c_password))
        con.commit()

class Volunteer:
    def vol_activity(self):
        cur.execute("select u_name,u_collegename,u_emailid,u_contactno from userdetails")
        print(cur.fetchall())
    def vol_winner(self):
        cur.execute("alter table userdetails add winner varchar2(15)")
        u_winname=input("Enter the winner name")
        cur.execute("update userdetails set winner = '1st prize' where u_name = :9" ,{'9': u_winname})
        cur.execute("select u_name,u_collegename,winner from userdetails ")
        print(cur.fetchall())
        con.commit()

class Admin:
     def ad_activity(self):
        cur.execute("select * from userdetails")
        print(cur.fetchall())
     def ad_ann(self):
         cur.execute("alter table userdetails add cashprize varchar2(15)")
         cur.execute("update userdetails set cashprize = '5000' where winner = '1st prize'")
         cur.execute("select u_name,u_collegename,winner,cashprize from userdetails ")
         print(cur.fetchall())
         con.commit()
class Login:
    def logdata(self):
        
        l_name=input("Enter the username")
        l_pass=input("Enter the password")
        cur.execute("select u_name,u_pass from control where u_name = :1 and u_pass = :2",(l_name,l_pass))
        cur.fetchall()
        
print("\t\t********EVENT MANAGEMENT SYSTEM**********\t")
print("Select The Appropriate Choice...")
print("   1.NEW PARTICIPANT\n   2.VOLUNTEER\n   3.ADMIN")
ch = int(input())
if ch == 1:
    ud = Userdetails()
    ud.getdata()
elif ch == 2:
    ln = Login()
    ln.logdata()
    vr = Volunteer()
    vr.vol_activity()
    vr.vol_winner()
elif ch== 3:
    ln=Login()
    ln.logdata()
    ad = Admin()
    ad.ad_activity()
    ad.ad_ann()
    
    
